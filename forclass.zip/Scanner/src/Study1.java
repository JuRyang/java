import java.util.Scanner;

public class Study1 {

	public static void main(String[] args) {
    System.out.println("================================================");
    System.out.println("|  이름        나이                       전화번호                  주소   |");
    System.out.println("================================================");
    System.out.println("|  홍길동      20            010-111-2222      서울   |");
    System.out.print("|  일지매      18             02-123-4567     경기도  |\n");
    System.out.println("================================================");

    System.out.print("\n");
    System.out.print("\n");
    System.out.print("\n");
    
    System.out.print("================================================\n");
    System.out.print("|  이름                   나이              전화번호                  주소   |\n");
    System.out.print("================================================\n");
    System.out.print("|  \"홍길동\"      20     010-111-2222         서울   |\n");
    System.out.print("|  \"일지매\"      18      02-123-4567        경기도  |\n");
    System.out.print("================================================");

    System.out.print("\n");
    System.out.print("\n");
    System.out.print("\n");
    

    System.out.println("====================================================");
    System.out.println("| name   age    man        phone   height    address|");
    System.out.println("====================================================");
    
    String a = "\"홍길동\""; 
    String b = "\"일지매\"";
    String c = "\"장옥정\"";
    
    int d = 20;
    int e = 18;
    int f = 14;
    
    boolean o;
    o = true;
    
    String str1 = "010-111-2222";
    String str2 = "02-123-4567";
    String str3 = "02-345-7890";
    
    double x = 175.12;
    double y = 180.01;
    double z = 155.78;
    
    String str4 = "\"경기도\"";
    String str5 = "\"서울\"";
    String str6 = "\"부산\"";
  
    System.out.println("|" + a +"  " + d + "           "   + str1 +   "  " +  x +"   " +  str4 + "|");
    System.out.println("|" + b +"  " + e + "           "   + str2 +   "   " +  y +"    " +  str5 + "|");
    System.out.println("|" + c +"  " + f + "           "   + str3 +   "   " +  z +"    " +  str6 + "|");
    System.out.println("====================================================");

    
    System.out.print("\n");
    System.out.print("\n");
    System.out.print("\n");
    
    
    Scanner scan = new Scanner(System.in);
    String name;
    System.out.print(">> name ");
    name = scan.next();
    System.out.print(">> name "+name);

    
    System.out.print("\n");

    
    Scanner scan2 = new Scanner(System.in);
    String age;
    System.out.print(">> age ");
    age = scan2.next();
    System.out.print(">> age "+age);
    

    
    System.out.print("\n");

    
    Scanner scan3 = new Scanner(System.in);
    String man;
    System.out.print(">> man ");
    man = scan3.next();
    System.out.print(">> man "+man);
    

    
    System.out.print("\n");

    
    Scanner scan4 = new Scanner(System.in);
    String phone;
    System.out.print(">> phone ");
    phone = scan4.next();
    System.out.print(">> phone "+phone);
    
  System.out.print("\n");

    
    Scanner scan5 = new Scanner(System.in);
    String height;
    System.out.print(">> height ");
    height = scan5.next();
    System.out.print(">> height "+height);
    
  System.out.print("\n");

    
    Scanner scan6 = new Scanner(System.in);
    String address;
    System.out.print(">> address ");
    address = scan6.next();
    System.out.print(">> address "+address);
    
    System.out.print("\n");
    System.out.print("\n");
    System.out.print("\n");
    System.out.print("\n");

    int q, p;
    q = 1;
    p = 2;
    
    
    
    
    
    

    
    
    
    
	}

}
