
public class ReStudy1 {

	public static void main(String[] args) {
		//변수의 선언
		String name;
		int age;
		boolean man;
		String phone;
		double height;
		String address;
		
		
		// 변수의 대입
		System.out.println("============================================================");
	    System.out.println("\\\tname\tage\tman\tphone\theight\taddress\\");
		System.out.println("============================================================");

		//변수의 대입
		
		
		

	}

}
