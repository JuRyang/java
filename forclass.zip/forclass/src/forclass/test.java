package forclass;



public class test {

	public static void main(String[] args) {
		// 1~ 100사이에 있는 숫자 중 짝수들의 합, 홀수들의 합을 구하라.
		
	/*	int sum1, sum2;
		sum1= 0;
		sum2= 0;
		
		
	for (int i =1; i <=100; i++) {
			if( i%2 ==1) {
				sum1 = sum1+i;
			}
			else {
				sum2 = sum2+i;
				
			}
		}
		System.out.println("sum;1"+sum1);
		System.out.println("sum;2"+sum2);
		
		
		
		char arrch[] = {'D','W','O','A','B'};
		// character array에서 'A'를 찾아서 'a'로 변경하고 출력하라
		/*
		for(int i = 0; i < arrch.length; i++) {
			//System.out.println("arrch="+arrch[i]);
			if(arrch[i] == 'A') {
				arrch[i] = 'a';
				
				
			}
			
		}
		*/
	/*	int index = 0;
		for(char c : arrch) {
			if(c == 'A') {
				arrch[index] = 'a';
			}
			index++;
		}
		
		
		
		
		
		
		for(int i = 0; i< arrch.length; i++) {
			System.out.println(arrch[i]);
			
		}
		
		*/
		
		
		
		
		
		
		/*
		 * 내가 푼거
		 * arrch = new char [4];
		 
		arrch[4] = 'a';
	
		
		System.out.println("arrch[4]"+arrch[4]);
		
	
		
		
		
		/*arrch = new char [4];
		arrch[4] = 'a';
		*/
		
		
		
		
		
		
		/*char arrch1[];
		char arrchtemp[] ;
		
		arrchtemp =arrch1;
		 System.out.println(" Atype[0]:"+ arrch1);
		
		
		
		
		arrch1 = new char [4];
		arrch1[2] = 'a';
		*/
		
		
		

	}

}
